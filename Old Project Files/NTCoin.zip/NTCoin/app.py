from flask import *
from flask.helpers import url_for
from flask_login import LoginManager, login_user, logout_user, login_required, current_user, UserMixin
from flask_sqlalchemy import SQLAlchemy
from blockchain import Block, Blockchain, Transaction
import os
from itsdangerous import URLSafeTimedSerializer
import stripe
from flask_qrcode import QRcode
import cv2
from detector.scanner import *

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///ntcoin.db'
app.config['SECRET_KEY'] = '123123123'
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.session_protection = "strong"
login_serializer = URLSafeTimedSerializer(app.secret_key)
db = SQLAlchemy(app)
blockchain = Blockchain()
stripe_keys = {
  'secret_key': 'sk_test_51HwsnwFqMlvMMS7XHrEwAWq7HyYiigagqksoTxfsUHjqkcQYm4blVvd7e7Ib1r029I50xvwmq6qJUszHYfvVp3j000fiH31L2r',
  'publishable_key': 'pk_test_51HwsnwFqMlvMMS7XXZWEcpTHERnRlS9qFN9LAnlSbAQ6V0bMRkMeRkD02n1qTdBsl1YcFr3sGVZgsHawnlSLSgSm00ydPlsByI'
}
stripe.api_key = stripe_keys['secret_key']
QRcode(app)
camera = cv2.VideoCapture(0)

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    username = db.Column(db.String(120), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(120), nullable=False)
    coinAmount = db.Column(db.Integer(), nullable=False)

    def __init__(self, name, username, email, password, coinAmount):
        self.name = name
        self.username = username
        self.email = email
        self.password = password
        self.coinAmount = coinAmount
    
    def __repr__(self):
        return '<User %r>' % self.username

class Nodes(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(120), unique=True, nullable=False)
    name = db.Column(db.String(120), nullable=False)
    service = db.Column(db.String(120), nullable=False)
    payment = db.Column(db.Integer, nullable=False)
    def __init__(self, username, name, service, payment):
        self.username = username
        self.name = name
        self.service = service
        self.payment = payment

class BlockchainDB(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    transactions = db.Column(db.String(80), nullable=False)
    time = db.Column(db.String(80), nullable=False)
    prev = db.Column(db.String(80), unique=True, nullable=False)
    nonce = db.Column(db.String(80), nullable=False)
    hash = db.Column(db.String(80), unique=True, nullable=False)
    def __init__(self, transactions, time, prev, nonce, hash):
        self.transactions = transactions;
        self.time = time;
        self.prev = '';
        self.nonse = 0;
        self.hash = self.calculateHash();

db.create_all()

@login_manager.user_loader # uloader  for login_manager
def load_user(user_id):
    return User.query.get(int(user_id))

@app.route("/")
def index():
    return render_template('home.html')

@app.route("/buy", methods = ['GET', 'POST'])
def buy():
    if current_user.is_authenticated:
        return render_template('buy.html', key=stripe_keys['publishable_key'])
    else:
        flash("Please Login")
        return redirect(url_for('login'))

@app.route('/checkout', methods=['POST'])
def checkout():

    amount = int(request.form["amount"])*100
    coinamount = int(request.form['amount'])


    customer = stripe.Customer.create(
        email='sample@customer.com',
        source=request.form['stripeToken']
    )

    stripe.Charge.create(
        customer=customer.id,
        amount=amount,
        currency='usd',
        description='Flask Charge'
    )
    Blockchain.addTransaction(Blockchain(), 'Admin', current_user.username, coinamount)
    user = User.query.filter_by(username = current_user.username).first()
    user.coinAmount = int(user.coinAmount) + coinamount
    db.session.commit()
    flash('Thanks! You bought '+ str(coinamount) + ' coins!')
    return redirect(url_for('buy'))

@app.route("/transaction", methods = ['GET', 'POST'])
def transaction():
    if current_user.is_authenticated:
        if request.method == 'POST':
            reciver = request.form['reciver']
            amt = request.form['amt']
            password = request.form['password']
            if password == current_user.password:
                if int(current_user.coinAmount) >= int(amt):
                    blockchain.addTransaction(current_user.name, reciver, amt)
                    user = User.query.filter_by(username = current_user.username).first()
                    ureciver = User.query.filter_by(username = reciver).first()
                    user.coinAmount = int(user.coinAmount) - int(amt)
                    ureciver.coinAmount = int(ureciver.coinAmount) + int(amt)
                    db.session.commit()
                    flash('Sucsessfuly transfered '+ amt +' coins to '+ ureciver.username)
                    return redirect(url_for('transaction'))
                else:
                    flash('Unsufficent coin amount')
                    return redirect(url_for('transaction'))
            else:
                flash('Unable to verify password')
                return redirect(url_for('transaction'))
        return render_template('transaction.html')
    else:
        flash("Please Login")
        return redirect(url_for('login'))

@app.route('/login', methods = ['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('profile'))
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = User.query.filter_by(email=str(email)).first()
        if not (user):
            flash('Invalid Email')
            return render_template('login.html')
        else:
            if user.password == password:  # check that user table have inputed password
                login_user(load_user(user.id))
                cuserid = current_user.id
                person = User.query.filter_by(id = cuserid).first()
                flash('Signed in sucsessfuly')
                return redirect(url_for('profile'))
            else:
                flash('Invalid Password')
                return render_template('login.html')
    return render_template('login.html')

@app.route('/logout', methods = ['GET', 'POST'])
def logout():
    if current_user.is_authenticated:
        logout_user()
        return redirect(url_for('index'))
    else:
        flash("Please Login")
        return redirect(url_for('login'))

@app.route('/signup', methods = ['GET', 'POST'])
def signup():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        username = request.form['username']
        password = request.form['password']
        emails = User.query.all()
        for e in emails:
            if e.email == email:
                flash('Email already in database')
                return redirect(url_for('signup'))
        db.session.add(User(name=name, username=username, email=email, password=password, coinAmount= 0))
        db.session.commit()
        user = User.query.filter_by(name=name, username=username, email=email, password=password, coinAmount= 0).first()
        login_user(load_user(user.id))
        flash('Sucsessfuly Signed Up')
        return redirect(url_for('profile'))
    return render_template('signup.html')

@app.route('/profile', methods = ['GET', 'POST'])
def profile():
    if current_user.is_authenticated:
        cuser = current_user
        return render_template('profile.html', user = current_user)
    else:
        flash("Please Login")
        return redirect(url_for('login'))

@app.route('/profile/edit', methods = ['GET', 'POST'])
def edit():
    if current_user.is_authenticated:
        cuser = current_user
        if request.method == 'POST':
            username = request.form['username']
            name = request.form['name']
            email = request.form['email']
            password = request.form['password']
            cuser.username = username
            cuser.name = name
            cuser.email = email
            cuser.password = password
            db.session.commit()
            flash('Profile updated successfuly')
            return redirect(url_for('profile'))
        return render_template('edit.html', user = current_user)
    else:
        flash("Please Login")
        return redirect(url_for('login'))

@app.route('/node', methods = ['GET', 'POST'])
def nodeinfo():
    return render_template('node.html')

@app.route('/node/signup', methods = ['GET', 'POST'])
def becomenode():
    if request.method == 'POST':
        name = request.form['name']
        service = request.form['service']
        amt = request.form['amt']
        username = current_user.username
        newnode = Nodes(username, name, service, amt)
        db.session.add(newnode)
        db.session.commit()
        flash('Your node was made sucsessfuly')
        return redirect(url_for('nodeinfo'))
    return render_template('becomenode.html')

@app.route('/node/<bname>', methods = ['GET', 'POST'])
def node(bname):
    nodedata = Nodes.query.filter_by(name='Bus').first()
    if bname == nodedata.name:
        return render_template('nodepage.html', node = nodedata)
    else:
        return render_template('becomenode.html')

if __name__ == '__main__':
    app.run(debug=True)