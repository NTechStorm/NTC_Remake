

from flask import Flask, render_template
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_user, logout_user, login_required, current_user, UserMixin
import os

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:////ntcoin.db'
app.config['SECRET_KEY']  = os.urandom(24)
db = SQLAlchemy(app)

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    name = db.Column(db.String(120), nullable = False)
    key = db.Column(db.String(120), unique=True, nullable = False)
    password = db.Column(db.String(120), nullable = False)
    transactions = db.relationship('Transactions', backref = 'username', lazy = True)

    def __init__(self, username, email, name, key, password, transactions):
        self.username = username
        self.email = email
        self.name = name
        self.key = key
        self.password = password
        self.transactions = transactions

class BlockchainDB(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    index = db.Column(db.String(800), nullable=False)
    transactions = db.Column(db.String(800), nullable=False)
    time = db.Column(db.String(800), nullable=False)
    prev = db.Column(db.String(800), nullable=False)
    nonce = db.Column(db.String(800), nullable=False)
    hash = db.Column(db.String(800), nullable=False)
    def __init__(self, index, transaction, time, prev, nonse):
        self.index = index
        self.transaction = transaction
        self.time = time
        self.prev = prev
        self.nonce = nonse

class Transactions(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sender = db.Column(db.String(80), nullable=False)
    reciver = db.Column(db.String(80), nullable=False)
    amt = db.Column(db.String(80), nullable=False)
    time = db.Column(db.String(80), nullable=False)
    hash = db.Column(db.String(80), nullable=False)
    username_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    def __init__(self, sender, reciever, amt, time, hash, username_id):
        self.sender = sender
        self.reciver = reciever
        self.amt = amt
        self.time = time
        self.hash = hash
        self.username_id = username_id

db.session.commit()

@login_manager.user_loader # uloader  for login_manager
def load_user(user_id):
    return User.query.get(int(user_id))

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/basictransaction')
def basictransaction():
    return render_template('basictransaction.html')

@app.route('/complextransaction')
def complextransaction():
    return render_template('complextransaction.html')

@app.route('/profile')
def profile():
    return render_template('profile.html')

@app.route('/editprofile')
def editprofile():
    return render_template('editprofile.html')

@app.route('/yourtransactions')
def yourtransactions():
    return render_template('yourtransactions.html')

@app.route('/buycoins')
def buycoins():
    return render_template('buycoins.html')    

@app.route('/login', methods = ['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('profile'))
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = User.query.filter_by(email=str(email)).first()
        if not (user):
            flash('Invalid Email')
            return render_template('login.html')
        else:
            if user.password == password:  # check that user table have inputed password
                login_user(load_user(user.id))
                cuserid = current_user.id
                person = User.query.filter_by(id = cuserid).first()
                flash('Signed in sucsessfuly')
                return redirect(url_for('profile'))
            else:
                flash('Invalid Password')
                return render_template('login.html')
    return render_template('login.html')

@app.route('/signup', methods = ['GET', 'POST'])
def signup():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        username = request.form['username']
        password = request.form['password']
        emails = User.query.all()
        for e in emails:
            if e.email == email:
                flash('Email already in database')
                return redirect(url_for('signup'))
        db.session.add(User(username, email, name, key=os.urandom(120), password=password, transactions = 'Null'))
        db.session.commit()
        login_user(load_user(user.id))
        flash('Sucsessfuly Signed Up')
        return redirect(url_for('profile'))
    return render_template('signup.html')

@app.route('/logout', methods = ['GET', 'POST'])
def logout():
    if current_user.is_authenticated:
        logout_user()
        return redirect(url_for('index'))
    else:
        flash("Please Login")
        return redirect(url_for('login'))